Shannon Ke

Packages utilized:
	scikit
	pandas

The project was coded in and tested with Spyder

Datasets were found through the UCI machine learning repository, and both datasets are small enough
to be submitted, so they are in the attached datasets folder, along with a text file describing the formatting
of each dataset.

To run the program, merely make sure that you are using a working python interpreter that
supports graphics for making the plots and that your datasets folder is in the same directory level as the code.

To plot different graphs:
	only one graph for each dataset is shown at a time. The nursery dataset corresponds with X and Y values, and
	the cars dataset corresponds with the W and Z values. To see just cars, comment out the X and Y values and
	classifying operations on them, and uncomment the corresponding algorithm calls on the W and Z values.

	Since most of the code was stolen from and operated from online, I did a bunch of changing around
	and testing code by altering values and then changing them while going to create the graphs. If there
	are any specific questions about how I got my graph, feel free to email me since it might not be readily
	obvious from the code and comments but is too long to document exactly. Sorry about that!
